package br.dev.joaquim.exceptions;

public class InsufficientFoundsException extends Exception {
  public InsufficientFoundsException(String message) {
    super(message);
  }
}
