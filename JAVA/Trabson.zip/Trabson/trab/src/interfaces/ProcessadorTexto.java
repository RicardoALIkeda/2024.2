package interfaces;
/*
Ricardo Andre Lopes Ikeda - 10390256
Diego Estevao Lopes de Queiroz - 10419038
 */

public interface ProcessadorTexto {
    String processar(String texto);
}