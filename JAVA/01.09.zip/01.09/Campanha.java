public abstract class Campanha {
    
    public abstract void configurar();
    public abstract void executar();
    public abstract void avaliar();
}
