/*
Diego Estevão Lopes de Queiroz - 10419038
Ricardo André Lopes Ikeda - 10390256
*/
package principal;
import model.GerenciadorNomes;
import model.GerenciadorNomesBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import view.Ihm;

public class Main {
    private static final String JDBC_URL = "jdbc:h2:file:c:/temp/h3nco";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "root";
    public static void main(String[] args) {
        try {
            Connection conexao = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
            conexao.close();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar ao banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
        GerenciadorNomes gNomes = new GerenciadorNomesBD(); 

        Ihm ihm = new Ihm(gNomes);
        ihm.dialogar();
    }
}