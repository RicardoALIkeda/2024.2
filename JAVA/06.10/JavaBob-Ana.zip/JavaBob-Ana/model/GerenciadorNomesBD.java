package model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;  

import java.util.ArrayList;
import java.util.List;

public class GerenciadorNomesBD implements GerenciadorNomes {

    private Connection conexao;

    public GerenciadorNomesBD() {
        try {
            conexao = DriverManager.getConnection("jdbc:h2:file:c:/temp/h3nco", "sa", "");


            criarTabela();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void criarTabela() throws SQLException {
        Statement stmt = conexao.createStatement();
        String sql = "CREATE TABLE IF NOT EXISTS nomes (" +
                     "id INT AUTO_INCREMENT PRIMARY KEY, " +
                     "nome VARCHAR(" + MAX_CARACTERES_NOMES + ") NOT NULL)";
        stmt.execute(sql);
        stmt.close();
    }

    @Override
    public List<String> obterNomes() {
        List<String> nomes = new ArrayList<>();
        try {
            Statement stmt = conexao.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT nome FROM nomes");
            while (rs.next()) {
                nomes.add(rs.getString("nome"));
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nomes;
    }

    @Override
    public void adicionarNome(String nome) {
        try {
            PreparedStatement stmt = conexao.prepareStatement("INSERT INTO nomes (nome) VALUES (?)");
            stmt.setString(1, nome);
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}